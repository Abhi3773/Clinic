import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-prescribed-medicine',
  templateUrl: './prescribed-medicine.component.html',
  styleUrls: ['./prescribed-medicine.component.scss']
})
export class PrescribedMedicineComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
