import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-prescribed-medicine-list',
  templateUrl: './prescribed-medicine-list.component.html',
  styleUrls: ['./prescribed-medicine-list.component.scss']
})
export class PrescribedMedicineListComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
