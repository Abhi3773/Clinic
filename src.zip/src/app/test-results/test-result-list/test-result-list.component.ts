import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-test-result-list',
  templateUrl: './test-result-list.component.html',
  styleUrls: ['./test-result-list.component.scss']
})
export class TestResultListComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
