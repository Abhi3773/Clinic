import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-prescription-list',
  templateUrl: './prescription-list.component.html',
  styleUrls: ['./prescription-list.component.scss']
})
export class PrescriptionListComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
