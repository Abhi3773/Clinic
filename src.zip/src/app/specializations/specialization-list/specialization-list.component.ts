import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-specialization-list',
  templateUrl: './specialization-list.component.html',
  styleUrls: ['./specialization-list.component.scss']
})
export class SpecializationListComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
