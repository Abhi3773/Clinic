export class TestResult {
}
