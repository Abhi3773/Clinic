import { TestResult } from './test-result';

describe('TestResult', () => {
  it('should create an instance', () => {
    expect(new TestResult()).toBeTruthy();
  });
});
