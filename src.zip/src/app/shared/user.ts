import{Role} from './role'
export class User {

    userId:number;
    userName:string;
    mobileNo:string;
    address:string;
    email:string;
    password:string;
    isActive:string;
    roleId:number;

    role:Role;
  
    
}
