import { PrescribedMedicine } from './prescribed-medicine';

describe('PrescribedMedicine', () => {
  it('should create an instance', () => {
    expect(new PrescribedMedicine()).toBeTruthy();
  });
});
