export class Specialization {
}
