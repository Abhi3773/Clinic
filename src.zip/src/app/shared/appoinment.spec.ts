import { Appoinment } from './appoinment';

describe('Appoinment', () => {
  it('should create an instance', () => {
    expect(new Appoinment()).toBeTruthy();
  });
});
