export class Prescription {
}
