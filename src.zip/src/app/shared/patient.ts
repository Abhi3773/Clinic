export class Patient {
    patientId:number;
    patientName:string;
    phone:string;
    address:string;
    email:string;
    bloodGroup:string;
    age:number;

    
}
