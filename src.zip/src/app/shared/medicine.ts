export class Medicine {
}
